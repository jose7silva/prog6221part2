﻿using System;

namespace RecipeApp
{
    // Represents an ingredient in a recipe
    class Ingredient
    {
        public string Name { get; set; }
        public double Quantity { get; set; }
        public string Unit { get; set; }
        public double Calories { get; set; }
        public string FoodGroup { get; set; }

        // Constructor to initialize the ingredient properties
        public Ingredient(string name, double quantity, string unit, double calories, string foodGroup)
        {
            Name = name;
            Quantity = quantity;
            Unit = unit;
            Calories = calories;
            FoodGroup = foodGroup;
        }

        // Returns a string representation of the ingredient
        public override string ToString()
        {
            return $"{Quantity} {Unit} {Name}";
        }
    }
}
