﻿using System;
using System.Collections.Generic;

namespace RecipeApp
{
    // Manages the recipes and provides operations on them
    class RecipeManager
    {
        private List<Recipe> recipes;
        public event Action<string> NotifyCalorieExceeds;

        // Constructor to initialize the recipe manager
        public RecipeManager()
        {
            recipes = new List<Recipe>();
        }

        // Adds a recipe to the manager
        public void AddRecipe(Recipe recipe)
        {
            recipes.Add(recipe);
            double totalCalories = recipe.CalculateTotalCalories();
            if (totalCalories > 300)
            {
                NotifyCalorieExceeds?.Invoke(recipe.Name);
            }
        }

        // Displays all the recipes in the manager
        public void DisplayRecipes()
        {
            recipes.Sort((r1, r2) => string.Compare(r1.Name, r2.Name));

            Console.WriteLine("Recipes:");
            foreach (Recipe recipe in recipes)
            {
                Console.WriteLine(recipe.Name);
            }
        }

        // Retrieves a recipe from the manager by its name
        public Recipe GetRecipe(string name)
        {
            return recipes.Find(r => r.Name == name);
        }

        // Clears all the recipes from the manager
        public void ClearRecipe()
        {
            recipes.Clear();
        }
    }
}
