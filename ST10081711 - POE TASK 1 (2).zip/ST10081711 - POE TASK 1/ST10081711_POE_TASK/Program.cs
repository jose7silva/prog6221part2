﻿using System;

namespace RecipeApp
{
    class Program
    {
        // Validates and returns a double value from user input
        public static double CheckInputTypes(string input, string inputName)
        {
            double value;
            if (double.TryParse(input, out value))
            {
                return value;
            }
            else
            {
                Console.Write($"Enter a valid value for {inputName}: ");
                return CheckInputTypes(Console.ReadLine(), inputName);
            }
        }

        // Validates and returns a non-empty string from user input
        public static string CheckInputString(string input, string inputName)
        {
            if (string.IsNullOrWhiteSpace(input))
            {
                Console.Write($"Enter a valid value for {inputName}: ");
                return CheckInputString(Console.ReadLine(), inputName);
            }
            else
            {
                return input.Trim();
            }
        }

        // Entry point of the application
        static void Main(string[] args)
        {
            RecipeManager recipeManager = new RecipeManager();

            while (true)
            {
                Console.WriteLine("\nRecipe App");
                Console.WriteLine("1. Add Recipe");
                Console.WriteLine("2. Display Recipes");
                Console.WriteLine("3. View Recipe");
                Console.WriteLine("4. Clear Recipe");
                Console.WriteLine("5. Exit");
                Console.Write("Enter your choice: ");
                string choice = Console.ReadLine();

                switch (choice)
                {
                    case "1":
                        Console.Write("Enter the name of the recipe: ");
                        string recipeName = CheckInputString(Console.ReadLine(), "recipe name");
                        Recipe newRecipe = new Recipe(recipeName);

                        Console.Write("Enter the number of ingredients: ");
                        string numIngredientsInput = Console.ReadLine();
                        int numIngredients;
                        if (int.TryParse(numIngredientsInput, out numIngredients) && numIngredients >= 0)
                        {
                            for (int i = 0; i < numIngredients; i++)
                            {
                                Console.Write($"Enter the name of ingredient {i + 1}: ");
                                string name = CheckInputString(Console.ReadLine(), "ingredient name");

                                Console.Write($"Enter the quantity of {name}: ");
                                string quantityInput = Console.ReadLine();
                                double quantity = CheckInputTypes(quantityInput, "quantity");

                                Console.Write($"Enter the unit of measurement for {name}: ");
                                string unit = CheckInputString(Console.ReadLine(), "unit of measurement");

                                Console.Write($"Enter the number of calories for {name}: ");
                                string caloriesInput = Console.ReadLine();
                                double calories = CheckInputTypes(caloriesInput, "calories");

                                Console.Write($"Enter the food group for {name}: ");
                                string foodGroup = CheckInputString(Console.ReadLine(), "food group");

                                newRecipe.AddIngredient(name, quantity, unit, calories, foodGroup);
                            }

                            recipeManager.AddRecipe(newRecipe);
                            Console.WriteLine("Recipe added successfully!");
                        }
                        else
                        {
                            Console.WriteLine("Invalid input for number of ingredients. Please enter a non-negative integer value.");
                        }
                        break;

                    case "2":
                        recipeManager.DisplayRecipes();
                        break;

                    case "3":
                        Console.Write("Enter the name of the recipe: ");
                        string selectedRecipeName = CheckInputString(Console.ReadLine(), "recipe name");
                        Recipe selectedRecipe = recipeManager.GetRecipe(selectedRecipeName);
                        if (selectedRecipe != null)
                        {
                            selectedRecipe.Display();
                        }
                        else
                        {
                            Console.WriteLine("Recipe not found.");
                        }
                        break;

                    case "4":
                        Console.Write("Are you sure you want to clear the recipe? (y/n): ");
                        string confirmation = Console.ReadLine();
                        if (confirmation.ToLower() == "y")
                        {
                            recipeManager.ClearRecipe();
                            Console.WriteLine("Recipe cleared successfully!");
                        }
                        break;

                    case "5":
                        Console.WriteLine("Exiting...");
                        return;

                    default:
                        Console.WriteLine("Invalid choice. Please try again.");
                        break;
                }
            }
        }
    }
}
